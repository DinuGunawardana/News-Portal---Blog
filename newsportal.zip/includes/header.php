<head>
<style>



.topnav {

  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #00acee;
  color: black;
}

.topnav a.active {
  background-color: #00acee;
  color: white;
}

.topnav-right {
  float: right;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: #00acee;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #00acee;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
</style>
</head>

<div class="topnav" style="margin-top: -56px;">
  <a class="active" href="http://localhost/cofi-m/index/index.php">COFI-M(PVT)LTD.</a>
  <div class="topnav-right">
    <a href="http://localhost/cofi-m/index/index.php">HOME</a>
      <a href="http://localhost/cofi-m/shopping/">PRODUCTS</a>
<!-- <div class="dropdown">
    <button class="dropbtn">PRODUCTS
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="http://localhost/cofi-m/shopping/category.php?cid=1">Hardware</a>
      <a href="http://localhost/cofi-m/shopping/category.php?cid=2">Tools</a>
      <a href="http://localhost/cofi-m/shopping/category.php?cid=3">Lighting</a>
    <a href="http://localhost/cofi-m/shopping/category.php?cid=4">Door & Window</a>
    <a href="http://localhost/cofi-m/shopping/category.php?cid=5l">Furniture</a>
    <a href="http://localhost/cofi-m/index/pages/gallery.html">Gallery</a>
    </div>
  </div>  --> 
  
  <a href="contact-us.php">CONTACT US</a>
  <a href="index.php">BLOG</a>
             
  </div>
</div>


<!--


<head>
<style>
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 17px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: #00acee;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #00acee;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

</style>
</head>

<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">



      <div class="container">
	  <a class="nav-link" href="http://localhost/cofi-m/index/index.php">COFI-M(PVT)LTD</a>                 -->
    <!--    <a class="navbar-brand" href="index.php"><img src="images/logo.png" height="50"></a>   --><!--
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
		  <li class="nav-item">
              <a class="nav-link" href="http://localhost/cofi-m/index/index.php">Home</a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="http://localhost/cofi-m/shopping/">Products</a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="http://localhost/cofi-m/index/index.php">About Us</a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="contact-us.php">Contact us</a>
            </li>
			
            <li class="nav-item">
              <a class="nav-link" href="index.php">Blog</a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="http://localhost/cofi-m/newsportal/admin/dashboard.php">Admin Portal</a>
            </li>
             
          </ul>
        </div>
      </div>
    </nav>


-->







